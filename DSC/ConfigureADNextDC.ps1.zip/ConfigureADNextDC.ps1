﻿configuration ConfigureADNextDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xDisk, cDisk, PSDesiredStateConfiguration

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
       	    ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }
        xADDomainController NextDC
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        Script script1
        {
			#
			# really the only thing we want to do here is to remove unneccessary forwarders.
			# However, the DNS service can be slow to start on WS2016 so we are forced to wait for that.
			#
            SetScript =
            {
                $dnsrunning = $false
                $triesleft = $Using:RetryCount
                While (-not $dnsrunning -and ($triesleft -gt 0))
                {
                    $triesleft--
                    try
                    {
                        $dnsrunning = (Get-Service -name dns).Status -eq "running"
                    } catch {
                        $dnsrunning = $false
                    }
                    if (-not $dnsrunning)
                    {
                        Write-Verbose -Verbose "Waiting $($Using:RetryIntervalSec) seconds for DNS service to start"
                        Start-Sleep -Seconds $Using:RetryIntervalSec
                    }
                }

                if (-not $dnsrunning)
                {
                    Write-Warning "DNS service is not running, cannot remove forwarder. Template deployement will fail"
                }
                $dnsFwdRule = Get-DnsServerForwarder
                $dnsFwdRule >> $logfile
                if ($dnsFwdRule.IPAddress)
                {
                    Write-Verbose -Verbose "Removing DNS forwarding rule"
                    try
                    {
                        Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force
                    } catch {
                        Write-Verbose -Verbose "Exception running Remove-DNSServerForwarder: $_"
                    }
                } else {
                    Write-Verbose -Verbose "No DNS forwarder found to remove"
                }
			}
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[xADDomainController]NextDC"
        }
    }
}
