﻿configuration ConfigureADNextDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xDisk, cDisk, PSDesiredStateConfiguration

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
       	    ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }
        xADDomainController NextDC
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        Script script1
        {
            SetScript =
            {
                $logfile = 'C:\WindowsAzure\Logs\nextdclog.txt'
                "start $(Get-Date)" >> $logfile  

                $dnsrunning = $false
                $triesleft = $RetryCount
                While (-not $dnsrunning -and ($triesleft -gt 0))
                {
                    $triesleft--
                    try
                    {
                        "checking if DNS service is running" >> $logfile
                        $dnsrunning = (Get-Service -name dns).Status -eq "running"
                    } catch {
                        "got exception $_" >> $logfile
                        $dnsrunning = $false
                    }
                    if (-not $dnsrunning)
                    {
                        "sleeping for $RetryIntervalSec seconds. Will try $triesleft more times if needed." >> $logfile
                        Write-Verbose -Verbose "Waiting $RetryIntervalSec seconds for DNS service to start"
                        Start-Sleep -Seconds $RetryIntervalSec
                    }
                }

                if (-not $dnsrunning)
                {
                    Write-Warning "DNS service is not running, cannot remove forwarder. Template deployement will fail"
                    "DNS service still not running! Next steps will generate errors. " >> $logfile
                }
                $dnsFwdRule = Get-DnsServerForwarder
                "next line(s) is dnsFwdRule" >> $logfile
                $dnsFwdRule >> $logfile
                if ($dnsFwdRule.IPAddress)
                {
                    Write-Verbose -Verbose "Removing DNS forwarding rule"
                    try
                    {
                        "executing Remove-DnsServerForwarder -IPAddress $($dnsFwdRule.IPAddress) -Force"  >> $logfile
                        Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force
                        "done removing" >> $logfile
                    } catch {
                        Write-Verbose -Verbose "Exception running Remove-DNSServerForwarder: $_"
                        "exception $($_)"
                    }
                } else {
                    "no forwarder"
                    Write-Verbose -Verbose "No DNS forwarder found to remove"
                }
                "done $(Get-Date)" >> $logfile              
			}
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[xADDomainController]NextDC"
        }
    }
}
