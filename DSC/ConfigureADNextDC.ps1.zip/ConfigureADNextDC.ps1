﻿configuration ConfigureADNextDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xDisk, cDisk

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
       	    ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }
        xADDomainController NextDC
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }
        Script script1
        {
            SetScript =
            {
                $logfile = 'C:\WindowsAzure\Logs\nextdclog.txt'
                "start $(Get-Date)" >> $logfile  
                $dnsFwdRule = Get-DnsServerForwarder
                "next line(s) is dnsFwdRule" >> $logfile
                $dnsFwdRule >> $logfile
                if ($dnsFwdRule.IPAddress)
                {
                    Write-Verbose -Verbose "Removing DNS forwarding rule"
                    try
                    {
                        "executing Remove-DnsServerForwarder -IPAddress $($dnsFwdRule.IPAddress) -Force"  >> $logfile
                        Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force
                        "done removing" >> $logfile
                    } catch {
                        Write-Verbose -Verbose "Exception running Remove-DNSServerForwarder: $_"
                        "exception $($_)"
                    }
                } else {
                    "no forwarder"
                    Write-Verbose -Verbose "No DNS forwarder found to remove"
                }
                "done $(Get-Date)" >> $logfile              
			}
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[xADDomainController]NextDC"
        }
    }
}
